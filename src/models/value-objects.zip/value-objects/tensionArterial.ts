import { FrecuenciaDistolica } from "./frecuenciaDistolica";
import { FrecuenciaSistolica } from "./frecuenciaSistolica";

export class TensionArterial {
  sistolica: FrecuenciaSistolica;
  diastolica: FrecuenciaDistolica;

  public constructor(sistolica: number, diastolica: number) {
    this.sistolica = new FrecuenciaSistolica(sistolica);
    this.diastolica = new FrecuenciaDistolica(diastolica);
  }
}